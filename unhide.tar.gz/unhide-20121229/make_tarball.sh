tar -T tar_list.txt -czvf unhide_20121229.tgz
